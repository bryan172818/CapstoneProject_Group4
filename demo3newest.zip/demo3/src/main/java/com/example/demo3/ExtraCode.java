/**
 * 
 */
package com.example.demo3;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * 
 */
public class ExtraCode {

//
//    @FXML
//    protected void onLoginButtonClick() {
//        String enteredUsername = usernameField.getText();
//        String enteredPassword = passwordField.getText();
//
//        if (enteredUsername.equals("Jeff") && enteredPassword.equals("Jeff1")) {
//
//
//            try {
//                FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
//                Parent root = loader.load();
//                Stage menuStage = new Stage();
//                menuStage.setScene(new Scene(root));
//                menuStage.show();
//
//
//                Stage loginStage = (Stage) usernameField.getScene().getWindow();
//                loginStage.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        } else {
//            //welcomeText.setText("Invalid username or password");
//        }
//    }
//    
    
    


// ... other methods ...
//@FXML
//protected void onSubmitButtonClick(ActionEvent event) {
//    // Get user input from the form
//    String enteredUsername = usernameField.getText();
//    String enteredPassword = password_Field.getText();
//    String enteredEmail = emailField.getText();  // Get email input
//
//    // Create a UserProfile object with the entered data
//    UserProfile userProfile = new UserProfile(enteredUsername, enteredEmail, enteredPassword);
//
//    // Add the UserProfile object to the list
//    userProfiles.add(userProfile);
//
//    // Display user information
//    System.out.println("User Credentials Stored:");
//    System.out.println("Username: " + userProfile.getUsername());
//    System.out.println("Email: " + userProfile.getEmail());
//    System.out.println("Password: " + userProfile.getPassword());
//
//    // Clear the input fields
//    usernameField.clear();
//    password_Field.clear();
//    emailField.clear();
//
//    // Optionally, you can save the userProfiles list to a file for persistent storage.
//}












// Rest of your code...

//@FXML first attepmt Dont delete yet!!!!!!!!!!!!!!!!!!!!!!!!!!!
//protected void onSubmitButtonClick(ActionEvent event) {
//    // Get user input from the form
//    String enteredUsername = usernameField.getText();
//    String enteredPassword = password_Field.getText();
//    // You can also get the emailField value if needed.
//
//    // Create a UserProfile object with the entered data
//    UserProfile userProfile = new UserProfile(enteredUsername, enteredPassword, ""); // Replace "" with the email if needed.
//
//    // Add the UserProfile object to the list
//    userProfiles.add(userProfile);
////
////    // Display a message to inform the user that the information has been stored
////    Alert alert = new Alert(Alert.AlertType.INFORMATION);
////    alert.setTitle("Information Stored");
////    alert.setHeaderText(null);
////    alert.setContentText("Your information has been stored.");
////    alert.showAndWait();
//    System.out.println("User Credentials Stored:");
//    System.out.println("Username: " + userProfile.getUsername());
//    System.out.println("Password: " + userProfile.getPassword());
//    
//    // Clear the input fields
//    usernameField.clear();
//    password_Field.clear();
//    // Clear emailField if needed.
//
//    // Optionally, you can save the userProfiles list to a file for persistent storage.
//
//   //// event.consume(); // Prevent further handling of the event
//}
//
@FXML
protected void onBackToLoginButtonClick(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
        Parent root = loader.load();

        Stage stage = new Stage();
        // Set the title for the login page
       // stage.setTitle("Login Page");
        stage.setScene(new Scene(root));

        stage.show();

        // Close the current stage (New Users page)
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}





//
//New Code for if the login is successful implement this!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//	@FXML
//	protected void onLoginUserButtonClick(ActionEvent event) {
//	    // Get user input from the form
//	    String enteredUsername = usernameField.getText();
//	    String enteredPassword = password_Field.getText();
//
//	    // Check if the entered username and password match any existing user profiles
//	    for (UserProfile userProfile : userProfiles) {
//	        if (userProfile.getUsername().equals(enteredUsername) && userProfile.getPassword().equals(enteredPassword)) {
//	            // Successful login
//	            openMenuPage();
//	            return;
//	        }
//	    }
//
//	    // If the loop finishes without finding a matching user, display an error message.
//	    displayError("Login Failed", "Invalid username or password.");
//	}
//
//	private void openMenuPage() {
//	    try {
//	        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
//	        Parent root = loader.load();
//
//	        Stage stage = new Stage();
//	        stage.setTitle("Menu Page");
//	        stage.setScene(new Scene(root));
//
//	        stage.show();
//
//	        // Close the current stage (Login page)
//	        Stage currentStage = (Stage) usernameField.getScene().getWindow();
//	        currentStage.close();
//	    } catch (IOException e) {
//	        e.printStackTrace();
//	    }
//	}
//???????????????????????????????????????????????????????????????????????????????????????????????????
//	
	
	
//
//private static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
//
//
//private List<UserProfile> userProfiles = new ArrayList<>(); // Store user profiles
//
//
//@FXML
//protected void onSubmitButtonClick() {
//  // Get user input from the form
//  String enteredUsername = usernameField.getText();
//  String enteredPassword = password_Field.getText();
//  String enteredEmail = emailField.getText(); // Get email input
//
//  // Check if the entered email is acceptable using regex pattern
//  if (!isValidEmail(enteredEmail)) {
//      displayError("Invalid Email", "Please enter a valid email address.");
//      return;
//  }
//
//  // Create a UserProfile object with the entered data
//  UserProfile userProfile = new UserProfile(enteredUsername, enteredEmail, enteredPassword);
//
//  // Add the UserProfile object to the list
//  userProfiles.add(userProfile);
//
//  // Display user information
//  System.out.println("User Credentials Stored:");
//  System.out.println("Username: " + userProfile.getUsername());
//  System.out.println("Email: " + userProfile.getEmail());
//  System.out.println("Password: " + userProfile.getPassword());
//  
//// Display a confirmation message
//  String confirmationMessage = enteredUsername + " has been created!";
//  messageLabel.setText(confirmationMessage);
//
//
//  // Clear the input fields
//  usernameField.clear();
//  password_Field.clear();
//  emailField.clear();
//
//  // Optionally, you can save the userProfiles list to a file for persistent storage.
//}
//
//// ...
//
//// Helper method to validate email using regex
//private boolean isValidEmail(String email) {
//  // Define a common email pattern using a well-known regex
//  String commonEmailPattern = ".+";
//  Pattern pattern = Pattern.compile(commonEmailPattern);
//  return pattern.matcher(email).matches();
//}
//
//// Helper method to display an error dialog
//private void displayError(String title, String message) {
//  Alert alert = new Alert(Alert.AlertType.ERROR);
//  alert.setTitle(title);
//  alert.setHeaderText(null);
//  alert.setContentText(message);
//  alert.showAndWait();
//}
//
//// ...
//












//
//// ... other methods ...
//@FXML
//protected void onSubmitButtonClick(ActionEvent event) {
//  // Get user input from the form
//  String enteredUsername = usernameField.getText();
//  String enteredPassword = password_Field.getText();
// String enteredEmail = emailField.getText();  // Get email input
//
// // Create a UserProfile object with the entered data
//  UserProfile userProfile = new UserProfile(enteredUsername, enteredEmail, enteredPassword);        
//  // Add the UserProfile object to the list
//  userProfiles.add(userProfile);
//
// // Display user information
// System.out.println("User Credentials Stored:");
// System.out.println("Username: " + userProfile.getUsername());
// System.out.println("Email: " + userProfile.getEmail());
//  System.out.println("Password: " + userProfile.getPassword());
//
//  // Clear the input fields
// usernameField.clear();
// password_Field.clear();
//  emailField.clear();
//
//  // Optionally, you can save the userProfiles list to a file for persistent storage.
//}


// Rest of your code...

//@FXML first attepmt Dont delete yet!!!!!!!!!!!!!!!!!!!!!!!!!!!
//protected void onSubmitButtonClick(ActionEvent event) {
//  // Get user input from the form
//  String enteredUsername = usernameField.getText();
//  String enteredPassword = password_Field.getText();
//  // You can also get the emailField value if needed.
//
//  // Create a UserProfile object with the entered data
//  UserProfile userProfile = new UserProfile(enteredUsername, enteredPassword, ""); // Replace "" with the email if needed.
//
//  // Add the UserProfile object to the list
//  userProfiles.add(userProfile);
////
////  // Display a message to inform the user that the information has been stored
////  Alert alert = new Alert(Alert.AlertType.INFORMATION);
////  alert.setTitle("Information Stored");
////  alert.setHeaderText(null);
////  alert.setContentText("Your information has been stored.");
////  alert.showAndWait();
//  System.out.println("User Credentials Stored:");
//  System.out.println("Username: " + userProfile.getUsername());
//  System.out.println("Password: " + userProfile.getPassword());
//  
//  // Clear the input fields
//  usernameField.clear();
//  password_Field.clear();
//  // Clear emailField if needed.
//
//  // Optionally, you can save the userProfiles list to a file for persistent storage.
//
// //// event.consume(); // Prevent further handling of the event
//}
//
}