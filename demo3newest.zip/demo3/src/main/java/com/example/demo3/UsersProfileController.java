

package com.example.demo3;


import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.io.*;
import java.util.List;
import javafx.scene.layout.VBox;


public class UsersProfileController implements Initializable {

	@FXML
    private Label welcomeLabel;

    @FXML
    private Label usernameLabel;

    private String enteredUsername;

    @FXML
    private VBox exerciseVBox; // Use VBox for exercise display

    private WorkoutLibrary workoutLibrary;

    public void setWorkoutLibrary(WorkoutLibrary workoutLibrary) {
        this.workoutLibrary = workoutLibrary;
    }

    public void setEnteredUsername(String enteredUsername) {
        this.enteredUsername = enteredUsername;
    }

 // Initialize method
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("Initializing UsersProfileController");
        
        // Load user profiles from the file
        List<UserProfile> userProfiles = loadUserProfilesFromFile();

        // Display the entered username
        if (enteredUsername != null) {
            welcomeLabel.setText("Welcome " + enteredUsername);
            usernameLabel.setText("Username: " + enteredUsername);
        }

        
        if (workoutLibrary != null) {
            exerciseVBox.getChildren().clear(); // Clear previous content
            
            // Debugging output: print the list of all exercises
            System.out.println("All exercises loaded:");
            List<Exercise> allExercises = workoutLibrary.getAllExercises();
            for (Exercise exercise : allExercises) {
                System.out.println(exercise); // This will invoke the toString() method of Exercise class
            }

            for (Exercise exercise : allExercises) {
                Label exerciseLabel = new Label(exercise.getName());
                // Customize the label or other UI elements here
                exerciseVBox.getChildren().add(exerciseLabel);
                System.out.println("Added exercise: " + exercise.getName());
            }
        } else {
            System.out.println("WorkoutLibrary is null");
        }
        
        
        
        
    }

    // Load user profiles from the file
    private List<UserProfile> loadUserProfilesFromFile() {
        List<UserProfile> userProfiles = null;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("userProfiles.dat"))) {
            userProfiles = (List<UserProfile>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return userProfiles;
    }
   
 // Inside UsersProfileController
    public void updateExercisesInView() {
        if (exerciseVBox != null && workoutLibrary != null) {
            exerciseVBox.getChildren().clear();
            for (Exercise exercise : workoutLibrary.getAllExercises()) {
                Label exerciseLabel = new Label(exercise.getName());
                exerciseVBox.getChildren().add(exerciseLabel);
            }
        } else {
            System.out.println("exerciseVBox or workoutLibrary is null");
        }
    }

}
	
	
	
	//  private Label welcomeLabel;
//
//    @FXML
//    private Label usernameLabel;
//
//    private String enteredUsername; // Add this field
//
//    @FXML
//    private ListView<String> exerciseListView;
//
//    private WorkoutLibrary workoutLibrary; // Reference to the workout library
//
//    public void setWorkoutLibrary(WorkoutLibrary workoutLibrary) {
//        this.workoutLibrary = workoutLibrary;
//    }
//
//    public void setEnteredUsername(String enteredUsername) {
//        this.enteredUsername = enteredUsername;
//    }
//    
//    
//
//    @Override
//    public void initialize(URL location, ResourceBundle resources) {
//    	 System.out.println("Initializing UsersProfileController");
//        // Load user profiles from the file
//        List<UserProfile> userProfiles = loadUserProfilesFromFile();
//
//        // Display the entered username
//        if (enteredUsername != null) {
//            welcomeLabel.setText("Welcome " + enteredUsername);
//            usernameLabel.setText("Username: " + enteredUsername);
//        }
//        
//     // Load and display exercises from the workout library
//        
//        if (workoutLibrary != null) {
//            ObservableList<String> exerciseNames = FXCollections.observableArrayList();
//            for (Exercise exercise : workoutLibrary.getAllExercises()) {
//                exerciseNames.add(exercise.getName());
//                System.out.println("Added exercise: " + exercise.getName()); // Debug statement
//            }
//            exerciseListView.setItems(exerciseNames);
//        }
//        
//        // Load and display exercises from the workout library
//        if (workoutLibrary != null) {
//            ObservableList<String> exerciseNames = FXCollections.observableArrayList();
//            for (Exercise exercise : workoutLibrary.getAllExercises()) {
//                exerciseNames.add(exercise.getName());
//            }
//            exerciseListView.setItems(exerciseNames);
//        }
//    }
//
//    // Load user profiles from the file
//    private List<UserProfile> loadUserProfilesFromFile() {
//        List<UserProfile> userProfiles = null;
//        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("userProfiles.dat"))) {
//            userProfiles = (List<UserProfile>) in.readObject();
//        } catch (IOException | ClassNotFoundException e) {
//            e.printStackTrace();
//        }
//        return userProfiles;
//    }
//
//    // ... Other methods and fields in your UsersProfileController class
//}
//    
//    
//    
//    
    
    
    
    
    
