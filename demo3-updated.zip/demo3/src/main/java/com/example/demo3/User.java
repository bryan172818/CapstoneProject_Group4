package com.example.demo3;

import java.util.ArrayList;
import java.util.List;

public class User {
    private final String username;
    private final String password;
    private final List<Appointment> appointments;
    private final List<WorkoutPlan> workoutPlans;
    private final List<HealthAssessment> healthAssessments;
    private final List<NutritionInfo> nutritionInfos;
    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.appointments = new ArrayList<>();
        this.workoutPlans = new ArrayList<>();
        this.healthAssessments = new ArrayList<>();
        this.nutritionInfos = new ArrayList<>();
    }
    public String getUsername() {
        return username;
    }
    public String getPassword() {
        return password;
    }
    public List<Appointment> getAppointments() {
        return appointments;
    }
    public List<WorkoutPlan> getWorkoutPlans() {
        return workoutPlans;
    }
    public List<HealthAssessment> getHealthAssessments() {
        return healthAssessments;
    }

    public List<NutritionInfo> getNutritionInfos() {
        return nutritionInfos;
    }
}

