package com.example.demo3;

import java.util.*;

public class FitnessApplication {
    private final Map<String, User> users;
    private User currentUser;
    private final Scanner scanner;

    public FitnessApplication() {
        this.users = new HashMap<>();
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        boolean exit = false;
        while (!exit) {
            System.out.println("Welcome to Fitness Application!");
            System.out.println("1. Login");
            System.out.println("2. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character
            switch (choice) {
                case 1:
                    login();
                    break;
                case 2:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        if (users.containsKey(username)) {
            User user = users.get(username);
            if (user.getPassword().equals(password)) {
                currentUser = user;
                System.out.println("Login successful!");
                showMainMenu();
            } else {
                System.out.println("Incorrect password. Please try again.");
            }
        } else {
            System.out.println("User not found. Please try again.");
        }
    }

    private void showMainMenu() {
        boolean logout = false;
        while (!logout) {
            System.out.println("\nMain Menu");
            System.out.println("1. Schedule Appointment");
            System.out.println("2. View Appointments");
            System.out.println("3. View Workout Plans");
            System.out.println("4. Track Workout Progress");
            System.out.println("5. Take Health Assessment");
            System.out.println("6. Get Nutrition Info");
            System.out.println("7. Logout");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character
            switch (choice) {
                case 1:
                    scheduleAppointment();
                    break;
                case 2:
                    viewAppointments();
                    break;
                case 3:
                    viewWorkoutPlans();
                    break;
                case 4:
                    trackWorkoutProgress();
                    break;
                case 5:
                    takeHealthAssessment();
                    break;
                case 6:
                    giveNutritionInfo();
                    break;
                case 7:
                    logout = true;
                    currentUser = null;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void scheduleAppointment() {
        System.out.print("Enter appointment date: ");
        String date = scanner.nextLine();
        System.out.print("Enter appointment time: ");
        String time = scanner.nextLine();
        System.out.print("Enter appointment description: ");
        String description = scanner.nextLine();
        Appointment appointment = new Appointment(date, time, description);
        currentUser.getAppointments().add(appointment);
        System.out.println("Appointment scheduled successfully!");
    }

    private void viewAppointments() {
        List<Appointment> appointments = currentUser.getAppointments();
        if (appointments.isEmpty()) {
            System.out.println("No appointments scheduled.");
        } else {
            System.out.println("\nAppointments:");
            for (Appointment appointment : appointments) {
                System.out.println("Date: " + appointment.getDate());
                System.out.println("Time: " + appointment.getTime());
                System.out.println("Description: " + appointment.getDescription());
                System.out.println();
            }
        }
    }

    private void viewWorkoutPlans() {
        List<String> monday = new ArrayList<>();
        monday.add("Chest press");
        monday.add("Incline dumbbell press");
        monday.add("Dumbbell flyes");
        monday.add("Push-ups");

        List<String> tuesday = new ArrayList<>();
        tuesday.add("Squats");
        tuesday.add("Leg press");
        tuesday.add("Lunges");
        tuesday.add("Calf raises");

        List<String> wednesday = new ArrayList<>();
        wednesday.add("Shoulder press");
        wednesday.add("Lateral raises");
        wednesday.add("Front raises");
        wednesday.add("Upright rows");

        List<String> thursday = new ArrayList<>();
        thursday.add("Deadlifts");
        thursday.add("Bent over rows");
        thursday.add("Lat pull-downs");
        thursday.add("Seated cable rows");

        List<String> friday = new ArrayList<>();
        friday.add("Bicep curls");
        friday.add("Tricep dips");
        friday.add("Hammer curls");
        friday.add("Tricep pushdowns");

        System.out.println("Monday Workout:");
        printWorkout(monday);

        System.out.println("Tuesday Workout:");
        printWorkout(tuesday);

        System.out.println("Wednesday Workout:");
        printWorkout(wednesday);

        System.out.println("Thursday Workout:");
        printWorkout(thursday);

        System.out.println("Friday Workout:");
        printWorkout(friday);
    }

    public static void printWorkout(List<String> workout) {
        for (String exercise : workout) {
            System.out.println(exercise);
        }
        System.out.println();
    }


    private void trackWorkoutProgress() {
        // Implement workout progress tracking logic here
        System.out.println("Workout progress tracking feature is not implemented yet.");
    }

    private void takeHealthAssessment() {
        System.out.print("Enter assessment date: ");
        String date = scanner.nextLine();
        System.out.print("Enter weight (in p): ");
        double weight = scanner.nextDouble();
        System.out.print("Enter height (in meters): ");
        double height = scanner.nextDouble();
        HealthAssessment healthAssessment = new HealthAssessment(date, weight, height);
        currentUser.getHealthAssessments().add(healthAssessment);
        System.out.println("Health assessment taken successfully!");
    }

    private void giveNutritionInfo() {
        System.out.print("Enter weight (in p): ");
        double weight = scanner.nextDouble();
        System.out.print("Enter height (in meters): ");
        double height = scanner.nextDouble();
        NutritionInfo nutritionInfo = new NutritionInfo(weight, height);
        currentUser.getNutritionInfos().add(nutritionInfo);

        if (nutritionInfo.getBmi() < 18.5) {
            System.out.println("55-65% of your daily calories should be from Carbohydrates.");
            double protein = 1.0 * nutritionInfo.getWeight();
            System.out.println("20-25% of your daily calories should be from Protein." +
                    "Try to intake " + protein + " grams of protein per day.");
            System.out.println("10-25% of your daily calories should be from Fats.");
            System.out.println("Try to consume more calories than you are burning to gain weight and build muscle.");
        }
        else if (nutritionInfo.getBmi() >= 18.5 && nutritionInfo.getBmi() < 25) {
            System.out.println("55-65% of your daily calories should be from Carbohydrates.");
            double protein = .9 * nutritionInfo.getWeight();
            System.out.println("20-25% of your daily calories should be from Protein." +
                    "Try to intake " + protein + " grams of protein per day.");
            System.out.println("10-25% of your daily calories should be from Fats.");
            System.out.println("Try to consume slightly more calories than you are burning to build muscle.");
        }
        else if (nutritionInfo.getBmi() >= 25 && nutritionInfo.getBmi() < 30) {
            System.out.println("45-55% of your daily calories should be from Carbohydrates.");
            double protein = .8 * nutritionInfo.getWeight();
            System.out.println("20-25% of your daily calories should be from Protein." +
                    "Try to intake " + protein + " grams of protein per day.");
            System.out.println("20-35% of your daily calories should be from Fats.");
            System.out.println("Try to consume the same amount calories as you are burning to build muscle.");
        }
        else if (nutritionInfo.getBmi() >= 30 && nutritionInfo.getBmi() < 35) {
            System.out.println("45-50% of your daily calories should be from Carbohydrates.");
            double protein = .9 * nutritionInfo.getWeight();
            System.out.println("20-25% of your daily calories should be from Protein." +
                    "Try to intake " + protein + " grams of protein per day.");
            System.out.println("20-35% of your daily calories should be from Fats.");
            System.out.println("Try to consume slightly less calories than you are burning to lose weight and build muscle.");
        }
        else if (nutritionInfo.getBmi() >= 35 ) {
            System.out.println("45-50% of your daily calories should be from Carbohydrates.");
            double protein = 1.0 * nutritionInfo.getWeight();
            System.out.println("20-25% of your daily calories should be from Protein." +
                    "Try to intake " + protein + " grams of protein per day.");
            System.out.println("20-35% of your daily calories should be from Fats.");
            System.out.println("Try to consume less calories than you are burning to lose weight and build muscle.");
        }
    }

    public static void main(String[] args) {
        FitnessApplication fitnessApp = new FitnessApplication();
        // Create some sample users
        User user1 = new User("user1", "password1");
        User user2 = new User("user2", "password2");
        fitnessApp.users.put(user1.getUsername(), user1);
        fitnessApp.users.put(user2.getUsername(), user2);
        fitnessApp.run();
    }
}
