package com.example.demo3;

public class HealthAssessment {
    private final String date;
    private final double weight;
    private final double height;
    private final double bmi;
    public HealthAssessment(String date, double weight, double height) {
        this.date = date;
        this.weight = weight;
        this.height = height;
        this.bmi = calculateBMI();
    }
    public String getDate() {
        return date;
    }
    public double getWeight() {
        return weight;
    }
    public double getHeight() {
        return height;
    }
    public double getBMI() {
        return bmi;
    }
    private double calculateBMI() {
        return weight / (height * height);
    }
}
